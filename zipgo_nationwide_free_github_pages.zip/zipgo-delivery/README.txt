ZIPGO — FREE GITHUB PAGES STARTER

This is a static website prototype for a nationwide-ready U.S. delivery brand.
It can be hosted free on GitHub Pages using a public GitHub repository.

PUBLISH FOR FREE
1. Sign in to GitHub or create a free account at https://github.com/.
2. Create a new PUBLIC repository named: zipgo-delivery
3. Upload index.html from this folder to the repository's root (not inside another folder).
4. In the repository, open Settings -> Pages.
5. Under "Build and deployment", choose "Deploy from a branch".
6. Select branch "main" and folder "/ (root)", then Save.
7. Wait for GitHub Pages to publish. The address will look like:
   https://YOUR-GITHUB-USERNAME.github.io/zipgo-delivery/
8. Open that address to check the site.

WHAT IS FREE IN THIS STARTER
- Static website hosting on GitHub Pages (subject to GitHub's current plan limits).
- Responsive website design.
- Service information and demo booking form.
- Illustrative USD estimate.
- Demo tracking for bookings saved in the same browser/device.

IMPORTANT LIMITATIONS — READ BEFORE PUBLIC LAUNCH
- This is a front-end prototype, not a functioning nationwide delivery company.
- The booking form does NOT send orders to an operator or courier. Demo bookings are saved in the visitor's browser only.
- Tracking is not live GPS tracking.
- There is no database, customer login, driver app, admin portal, payment processing, SMS/email notification, dispatch, or courier network.
- Nationwide branding does not mean courier service is currently available in all 50 states. Before taking real orders, establish courier coverage and operating procedures in each area.
- Replace the placeholder support email (support@zipgo.example) with a real business email.
- Do not collect real customer addresses, payment details, or sensitive information through this demo.
- For real operations, add a secure backend/database, authentication, live rate and service-area checks, dispatch tools, payment provider, privacy policy, terms, and customer support.

The demo uses only HTML, CSS, and browser JavaScript. No paid libraries are required.
